#import gym
#import numpy as np
#import torch as T
#from actor_critic_torch import Agent
#from utils import plot_learning_curve
#from  Tank_Sistemi_5  import FOS
import pickle
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from openpyxl import Workbook

if __name__ == '__main__':
    parametreler=[[0, 0.01],[0, 0.05],[0, 0.1],[0, 0.2],[1, 0.01],[1, 0.05],[1, 0.1],[1, 0.2],[2, 0.01],[2, 0.05],[2, 0.1],[2, 0.2]]
    parametreler=[[0, 0.05]]
    plt.figure()
    fig, ax = plt.subplots(4, 1)
    excel_veri=[]
    excel_veri_ort=[]
    data_veri_okunan=[]
    data_veri_okunan_sure=[]
    data=[]
    data_sure=[]
#    for dongu in range(0,1):
#        for par in parametreler:
    dongu=0;
    durum=1;
    son="0_01.pickle"
    Ajan_isim='D:/Qlearning/Actor-Critic-Methods-Paper-To-Code-master/ActorCritic_Q_Epsilon_x_y_z_epsilon_0_05_0_1-acrobat/Veriler_Düzenli/'
    Score_isim=Ajan_isim+"v_3_Scores_"+str(dongu)+"_durum_"+str(durum)+"_random_"+son
#    Score_isim="v_3_Scores_"+str(dongu)+"_durum_"+str(par[0])+"_random_"+str(par[1])
    Score_isim_sure=Ajan_isim+"v_3_Scores_sure_dongu_"+str(dongu)+"_durum_"+str(durum)+"_random_"+son
#
#    with open("D:/Qlearning/Actor-Critic-Methods-Paper-To-Code-master/ActorCritic_Q_Epsilon_x_y_z_epsilon_0_05_0_1-acrobat/Veriler_Düzenli/v_3_Scores_0_durum_0_random_0_01.pickle", "rb") as f:
#        data_sure.append(pickle.load(f))
    
    Ajan_isim='D:/Qlearning/Actor-Critic-Methods-Paper-To-Code-master/ActorCritic_Q_Epsilon_x_y_z_epsilon_0_05_0_1-acrobat/Veriler_Düzenli/'
    dongu=0;
    durum=1;
    son="0_01.pickle"
    for dongu in range(0,30):
        Score_isim=Ajan_isim+"v_3_Scores_"+str(dongu)+"_durum_"+str(durum)+"_random_"+son  
        Score_isim_sure=Ajan_isim+"v_3_Scores_sure_dongu_"+str(dongu)+"_durum_"+str(durum)+"_random_"+son
        with open(Score_isim, "rb") as f:
            data_veri_okunan.append(pickle.load(f))  
        with open(Score_isim_sure, "rb") as f:
            data_veri_okunan_sure.append(pickle.load(f)) 
   
    # DataFrame'leri oluştur
    df_scores = pd.DataFrame(data_veri_okunan)
    df_sure = pd.DataFrame(data_veri_okunan_sure)
    
    # Excel'e iki ayrı sayfaya yaz
    with pd.ExcelWriter("durum_1_veri_ort_0_01.xlsx", engine="openpyxl") as writer:
        df_scores.to_excel(writer, sheet_name="0_01", index=False, header=False)
        df_sure.to_excel(writer, sheet_name="0_01_Sure", index=False, header=False)
        
        
    excel_veri=[]
    excel_veri_ort=[]
    data_veri_okunan=[]
    data_veri_okunan_sure=[]
    data=[]
    data_sure=[]
    dongu=0;
    durum=1;
    son="0_05.pickle"
    for dongu in range(0,30):
        Score_isim=Ajan_isim+"v_3_Scores_"+str(dongu)+"_durum_"+str(durum)+"_random_"+son  
        Score_isim_sure=Ajan_isim+"v_3_Scores_sure_dongu_"+str(dongu)+"_durum_"+str(durum)+"_random_"+son
        with open(Score_isim, "rb") as f:
            data_veri_okunan.append(pickle.load(f))  
        with open(Score_isim_sure, "rb") as f:
            data_veri_okunan_sure.append(pickle.load(f)) 
   
    # DataFrame'leri oluştur
    df_scores = pd.DataFrame(data_veri_okunan)
    df_sure = pd.DataFrame(data_veri_okunan_sure)
    
    # Excel'e iki ayrı sayfaya yaz
    with pd.ExcelWriter("durum_1_veri_ort_0_05.xlsx", engine="openpyxl") as writer:
        df_scores.to_excel(writer, sheet_name="0_05", index=False, header=False)
        df_sure.to_excel(writer, sheet_name="0_05_Sure", index=False, header=False)
        
    excel_veri=[]
    excel_veri_ort=[]
    data_veri_okunan=[]
    data_veri_okunan_sure=[]
    data=[]
    data_sure=[]
    dongu=0;
    durum=1;
    son="0_1.pickle"
    for dongu in range(0,30):
        Score_isim=Ajan_isim+"v_3_Scores_"+str(dongu)+"_durum_"+str(durum)+"_random_"+son  
        Score_isim_sure=Ajan_isim+"v_3_Scores_sure_dongu_"+str(dongu)+"_durum_"+str(durum)+"_random_"+son
        with open(Score_isim, "rb") as f:
            data_veri_okunan.append(pickle.load(f))  
        with open(Score_isim_sure, "rb") as f:
            data_veri_okunan_sure.append(pickle.load(f)) 
   
    # DataFrame'leri oluştur
    df_scores = pd.DataFrame(data_veri_okunan)
    df_sure = pd.DataFrame(data_veri_okunan_sure)
    
    # Excel'e iki ayrı sayfaya yaz
    with pd.ExcelWriter("durum_1_veri_ort_0_1.xlsx", engine="openpyxl") as writer:
        df_scores.to_excel(writer, sheet_name="0_1", index=False, header=False)
        df_sure.to_excel(writer, sheet_name="0_1_Sure", index=False, header=False)
        
        
    excel_veri=[]
    excel_veri_ort=[]
    data_veri_okunan=[]
    data_veri_okunan_sure=[]
    data=[]
    data_sure=[]
    dongu=0;
    durum=1;
    son="0_2.pickle"
    for dongu in range(0,30):
        Score_isim=Ajan_isim+"v_3_Scores_"+str(dongu)+"_durum_"+str(durum)+"_random_"+son  
        Score_isim_sure=Ajan_isim+"v_3_Scores_sure_dongu_"+str(dongu)+"_durum_"+str(durum)+"_random_"+son
        with open(Score_isim, "rb") as f:
            data_veri_okunan.append(pickle.load(f))  
        with open(Score_isim_sure, "rb") as f:
            data_veri_okunan_sure.append(pickle.load(f)) 
   
    # DataFrame'leri oluştur
    df_scores = pd.DataFrame(data_veri_okunan)
    df_sure = pd.DataFrame(data_veri_okunan_sure)
    
    # Excel'e iki ayrı sayfaya yaz
    with pd.ExcelWriter("durum_1_veri_ort_0_2.xlsx", engine="openpyxl") as writer:
        df_scores.to_excel(writer, sheet_name="0_2", index=False, header=False)
        df_sure.to_excel(writer, sheet_name="0_2_Sure", index=False, header=False)
    



            
            